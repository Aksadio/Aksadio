#!/usr/bin/env python3
"""
Convert a prepped grayscale photo (see prep_photo.py) into a monospace
ASCII-art portrait, rendered as a terminal-styled SVG.

Usage:
    python scripts/make_ascii_svg.py <prepped_png> [output_svg]

Requires Pillow: pip install pillow --break-system-packages
"""
import sys

from PIL import Image

# dark -> light ramp; index into this by pixel brightness
RAMP = "@%#*+=-:. "

BG = "#0d1117"
FG = "#c9d1d9"
ACCENT = "#22d3ee"

CHAR_W = 6.1
CHAR_H = 11


def image_to_ascii_rows(img: Image.Image) -> list[str]:
    w, h = img.size
    pixels = img.load()
    rows = []
    for y in range(h):
        row = []
        for x in range(w):
            brightness = pixels[x, y]  # 0 (black) - 255 (white)
            idx = int((brightness / 255) * (len(RAMP) - 1))
            row.append(RAMP[idx])
        rows.append("".join(row))
    return rows


def rows_to_svg(rows: list[str]) -> str:
    if not rows:
        return ""
    n_rows = len(rows)
    n_cols = max(len(r) for r in rows)
    width = n_cols * CHAR_W + 20
    height = n_rows * CHAR_H + 20

    lines = []
    for i, row in enumerate(rows):
        escaped = row.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        y = 10 + (i + 1) * CHAR_H
        lines.append(
            f'<text x="10" y="{y}" xml:space="preserve" fill="{FG}">{escaped}</text>'
        )

    svg = f"""<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {width:.0f} {height:.0f}" width="{width:.0f}" height="{height:.0f}">
  <rect width="100%" height="100%" fill="{BG}" rx="8"/>
  <style>
    text {{ font-family: 'SFMono-Regular', Consolas, 'Liberation Mono', Menlo, monospace;
            font-size: 10px; white-space: pre; }}
  </style>
  {''.join(lines)}
  <rect x="4" y="4" width="{width - 8:.0f}" height="{height - 8:.0f}" fill="none"
        stroke="{ACCENT}" stroke-opacity="0.35" stroke-width="1" rx="6"/>
</svg>"""
    return svg


def main():
    if len(sys.argv) < 2:
        print("usage: make_ascii_svg.py <prepped_png> [output_svg]")
        sys.exit(1)
    inp = sys.argv[1]
    out = sys.argv[2] if len(sys.argv) > 2 else "avi-ascii.svg"

    img = Image.open(inp).convert("L")
    rows = image_to_ascii_rows(img)
    svg = rows_to_svg(rows)

    with open(out, "w") as f:
        f.write(svg)
    print(f"wrote {out}")


if __name__ == "__main__":
    main()
