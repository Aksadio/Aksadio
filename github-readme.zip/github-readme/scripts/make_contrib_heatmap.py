#!/usr/bin/env python3
"""
Fetch real GitHub contribution data (GraphQL) and render it as a terminal-styled
SVG heatmap for the profile README.

Usage:
    GITHUB_TOKEN=xxxx python scripts/make_contrib_heatmap.py <github_username> [output_svg]

Requires a GitHub token with at least `read:user` scope. In the GitHub Actions
workflow this is provided automatically via `secrets.GITHUB_TOKEN` (classic
token needed for the contributionsCollection field on private repos too, so a
PAT stored as a repo secret, e.g. GH_PAT, is recommended over the default
token if you want private contributions included).
"""

import json
import os
import sys
import urllib.request

GRAPHQL_URL = "https://api.github.com/graphql"

QUERY = """
query($login: String!) {
  user(login: $login) {
    contributionsCollection {
      contributionCalendar {
        totalContributions
        weeks {
          contributionDays {
            date
            contributionCount
            color
          }
        }
      }
    }
  }
}
"""

# terminal-dark palette (matches README theme)
BG = "#0d1117"
CELL_EMPTY = "#161b22"
SCALE = ["#0e2f1c", "#146c34", "#1fa851", "#39d353", "#7CFFA0"]
TEXT = "#8b949e"
ACCENT = "#22d3ee"

CELL = 11
GAP = 3


def fetch_calendar(login: str, token: str) -> dict:
    body = json.dumps({"query": QUERY, "variables": {"login": login}}).encode()
    req = urllib.request.Request(
        GRAPHQL_URL,
        data=body,
        headers={
            "Authorization": f"bearer {token}",
            "Content-Type": "application/json",
            "User-Agent": "profile-readme-heatmap",
        },
    )
    with urllib.request.urlopen(req, timeout=30) as resp:
        data = json.loads(resp.read())
    return data["data"]["user"]["contributionsCollection"]["contributionCalendar"]


def level_for_count(count: int, max_count: int) -> int:
    if count == 0:
        return 0
    if max_count <= 0:
        return 1
    ratio = count / max_count
    if ratio > 0.75:
        return 4
    if ratio > 0.5:
        return 3
    if ratio > 0.25:
        return 2
    return 1


def render_svg(calendar: dict, login: str) -> str:
    weeks = calendar["weeks"]
    total = calendar["totalContributions"]
    max_count = max(
        (d["contributionCount"] for w in weeks for d in w["contributionDays"]),
        default=0,
    )

    width = 40 + len(weeks) * (CELL + GAP)
    height = 100

    cells = []
    for wi, week in enumerate(weeks):
        for di, day in enumerate(week["contributionDays"]):
            level = level_for_count(day["contributionCount"], max_count)
            color = CELL_EMPTY if level == 0 else SCALE[level - 1]
            x = 30 + wi * (CELL + GAP)
            y = 34 + di * (CELL + GAP)
            cells.append(
                f'<rect x="{x}" y="{y}" width="{CELL}" height="{CELL}" rx="2" '
                f'fill="{color}"><title>{day["date"]}: {day["contributionCount"]} '
                f'contribution(s)</title></rect>'
            )

    legend_x = width - 130
    legend = [
        f'<text x="{legend_x - 30}" y="{height - 8}" fill="{TEXT}" '
        f'font-size="10" font-family="monospace">less</text>'
    ]
    for i, c in enumerate([CELL_EMPTY] + SCALE):
        lx = legend_x + i * (CELL + 2)
        legend.append(
            f'<rect x="{lx}" y="{height - 18}" width="{CELL - 1}" height="{CELL - 1}" '
            f'rx="2" fill="{c}"/>'
        )
    legend.append(
        f'<text x="{legend_x + 6 * (CELL + 2) + 4}" y="{height - 8}" fill="{TEXT}" '
        f'font-size="10" font-family="monospace">more</text>'
    )

    svg = f"""<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {width} {height}" width="{width}" height="{height}">
  <rect width="100%" height="100%" fill="{BG}" rx="6"/>
  <text x="14" y="18" fill="{ACCENT}" font-size="11" font-family="monospace">
    {login} :: {total} contributions in the last year
  </text>
  {''.join(cells)}
  {''.join(legend)}
</svg>"""
    return svg


def placeholder_svg(login: str) -> str:
    """Used when no token is available yet, so the README never breaks."""
    return f"""<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 860 100" width="860" height="100">
  <rect width="100%" height="100%" fill="{BG}" rx="6"/>
  <text x="14" y="20" fill="{ACCENT}" font-size="12" font-family="monospace">
    {login} :: contribution graph
  </text>
  <text x="14" y="58" fill="{TEXT}" font-size="12" font-family="monospace">
    waiting for first workflow run to pull real data...
  </text>
</svg>"""


def main():
    if len(sys.argv) < 2:
        print("usage: make_contrib_heatmap.py <github_username> [output_svg]")
        sys.exit(1)

    login = sys.argv[1]
    out_path = sys.argv[2] if len(sys.argv) > 2 else "contrib-heatmap.svg"
    token = os.environ.get("GITHUB_TOKEN") or os.environ.get("GH_PAT")

    if not token:
        svg = placeholder_svg(login)
    else:
        calendar = fetch_calendar(login, token)
        svg = render_svg(calendar, login)

    with open(out_path, "w") as f:
        f.write(svg)
    print(f"wrote {out_path}")


if __name__ == "__main__":
    main()
