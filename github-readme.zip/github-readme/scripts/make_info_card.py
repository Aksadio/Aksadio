#!/usr/bin/env python3
"""
Render a neofetch-style "whoami" info card as an SVG for the profile README.

Edit the PROFILE dict below and re-run:
    python scripts/make_info_card.py [output_svg]
"""
import sys

BG = "#0d1117"
BORDER = "#22d3ee"
LABEL = "#22d3ee"
VALUE = "#c9d1d9"
MUTED = "#8b949e"
NAME_COLOR = "#39d353"

PROFILE = {
    "name": "Shahariar Azim Aksad",
    "handle": "@Aksadio",
    "tagline": "AI Builder · Instructor",
    "location": "Chittagong, Bangladesh",
    "experience": "Learning — building real projects while studying CS50x / CS50P",
    "stack": ["Python", "n8n", "Gemini API", "Google AI Studio", "Claude", "VS Code", "Hostinger", "Replit"],
    "highlights": ["AWS", "Google", "Kaggle", "Claude"],
}

ROW_H = 22
PAD = 20
LABEL_W = 110


def wrap(text: str, width: int) -> list[str]:
    words = text.split()
    lines, cur = [], ""
    for w in words:
        trial = (cur + " " + w).strip()
        if len(trial) > width:
            if cur:
                lines.append(cur)
            cur = w
        else:
            cur = trial
    if cur:
        lines.append(cur)
    return lines or [""]


def main():
    out = sys.argv[1] if len(sys.argv) > 1 else "info-card.svg"

    rows = []
    y = PAD + 54  # header height

    def add_row(label, value_lines):
        nonlocal y
        rows.append((label, value_lines, y))
        y += ROW_H * len(value_lines)

    add_row("location", [PROFILE["location"]])
    add_row("experience", wrap(PROFILE["experience"], 34))
    add_row("stack", wrap(", ".join(PROFILE["stack"]), 34))
    add_row("highlights", wrap(", ".join(PROFILE["highlights"]), 34))

    height = y + PAD
    width = 490

    body = []
    body.append(f'<text x="{PAD}" y="{PAD + 22}" fill="{NAME_COLOR}" font-size="18" '
                 f'font-weight="bold" font-family="monospace">{PROFILE["name"]}</text>')
    body.append(f'<text x="{PAD}" y="{PAD + 40}" fill="{MUTED}" font-size="12" '
                 f'font-family="monospace">{PROFILE["handle"]} · {PROFILE["tagline"]}</text>')
    body.append(f'<line x1="{PAD}" y1="{PAD + 50}" x2="{width - PAD}" y2="{PAD + 50}" '
                 f'stroke="{BORDER}" stroke-opacity="0.35"/>')

    for label, value_lines, ry in rows:
        body.append(f'<text x="{PAD}" y="{ry}" fill="{LABEL}" font-size="12" '
                     f'font-family="monospace">{label}</text>')
        for j, line in enumerate(value_lines):
            esc = line.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
            body.append(f'<text x="{PAD + LABEL_W}" y="{ry + j * ROW_H}" fill="{VALUE}" '
                         f'font-size="12" font-family="monospace">{esc}</text>')

    svg = f"""<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {width} {height}" width="{width}" height="{height}">
  <rect width="100%" height="100%" fill="{BG}" rx="8"/>
  <rect x="4" y="4" width="{width - 8}" height="{height - 8}" fill="none"
        stroke="{BORDER}" stroke-opacity="0.35" stroke-width="1" rx="6"/>
  {''.join(body)}
</svg>"""

    with open(out, "w") as f:
        f.write(svg)
    print(f"wrote {out}")


if __name__ == "__main__":
    main()
