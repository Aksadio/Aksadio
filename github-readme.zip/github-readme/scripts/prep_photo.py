#!/usr/bin/env python3
"""
Prepare an uploaded photo for ASCII-art conversion: crop to a portrait
aspect ratio, resize down, and convert to grayscale.

Usage:
    python scripts/prep_photo.py <input_photo> [output_png]

Requires Pillow: pip install pillow --break-system-packages
"""
import sys

from PIL import Image, ImageOps


def prep(input_path: str, output_path: str, target_width: int = 100):
    img = Image.open(input_path)
    img = ImageOps.exif_transpose(img)  # respect camera orientation
    img = img.convert("L")  # grayscale

    # center-crop to a 3:4 portrait aspect ratio
    w, h = img.size
    target_ratio = 3 / 4
    current_ratio = w / h
    if current_ratio > target_ratio:
        new_w = int(h * target_ratio)
        left = (w - new_w) // 2
        img = img.crop((left, 0, left + new_w, h))
    else:
        new_h = int(w / target_ratio)
        top = (h - new_h) // 2
        img = img.crop((0, top, w, top + new_h))

    # resize down; ASCII chars are taller than wide so shrink height more
    w, h = img.size
    new_w = target_width
    new_h = int(target_width * (h / w) * 0.55)
    img = img.resize((new_w, new_h), Image.LANCZOS)

    # mild contrast boost so ASCII levels read cleanly
    img = ImageOps.autocontrast(img, cutoff=2)

    img.save(output_path)
    print(f"prepped {input_path} -> {output_path} ({new_w}x{new_h})")


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("usage: prep_photo.py <input_photo> [output_png]")
        sys.exit(1)
    inp = sys.argv[1]
    out = sys.argv[2] if len(sys.argv) > 2 else "prepped.png"
    prep(inp, out)
